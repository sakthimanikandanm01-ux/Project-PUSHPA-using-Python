# PUSHPA > 2025-07-16 8:17pm
https://universe.roboflow.com/project-suraa/pushpa-ijaxx

Provided by a Roboflow user
License: CC BY 4.0

